package com.merit.tlgapp.model;

public class CommonInfo {
private String instructions_to_fill;
private String scoring_guidelines;
private String remarks;
private String title;
public String getInstructions_to_fill() {
	return instructions_to_fill;
}
public void setInstructions_to_fill(String instructions_to_fill) {
	this.instructions_to_fill = instructions_to_fill;
}
public String getScoring_guidelines() {
	return scoring_guidelines;
}
public void setScoring_guidelines(String scoring_guidelines) {
	this.scoring_guidelines = scoring_guidelines;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
}
