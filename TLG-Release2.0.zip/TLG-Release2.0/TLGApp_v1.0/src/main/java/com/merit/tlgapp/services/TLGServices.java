package com.merit.tlgapp.services;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.merit.tlg.dashboard.business.DashboardServiceWrapper;
import com.merit.tlgscg.scorecard.ScoreCardGenerator;
import com.merit.tlgapp.dbutility.DBUtility;
import com.merit.tlgapp.exception.MissingRequestParameterException;
import com.merit.tlgapp.exception.TLGException;
import com.merit.tlgapp.model.*;
import com.merit.tlgapp.model.generic.*;
import com.merit.tlgapp.utility.AppUtility;

public class TLGServices {
	static {
		System.setProperty("log4j.configurationFile", "log4j.properties");
	}
	static Logger szLogger = LogManager.getLogger(TLGServices.class.getName());

	public static Page getQuestionnairePage(GenericRequest request) throws TLGException {
		JSONArray pageJSON = null, szJArray = null;
		Page szTLGPage = null;
		JSONObject szJObj = null;
		Dimension szDim = null;
		Question szQues = null;
		String szStr = null, parDimName = null, secDimName = null, metricID = null;
		Metric szMet = null;
		Option szOpt = null;
		String[] optLables = null, optIDs = null, spliArr = null;
		Integer dimID = null, parDimID = null;
		Key szPageKey = null;
		int no_of_questions = 0;
		PageQuestion szPQtn = null;
		String questionID = null;
		int optionID = -1;
		PrintWriter pw = null;
		StringWriter sw = null;
		
		try {
			pageJSON = DBUtility.getPage(request.getProjectID(), request.getToolID(), request.getQuestionnaireID(), request.getPageID());
			szLogger.debug("pageJSON::" + pageJSON);
			szTLGPage = new Page();
			for (int i = 0; i < pageJSON.length(); i++) {
				optionID = -1;
				szJObj = pageJSON.getJSONObject(i);
				szLogger.debug("szJObj::" + szJObj);
				dimID = szJObj.getInt("dimension_id");
				questionID = szJObj.getString("question_id");

				metricID = szJObj.getString("response_metric_id");
				szJArray = DBUtility.getResponseMetric(metricID);
				for (int j = 0; j < szJArray.length(); j++) {
					szStr = szJArray.getJSONObject(j).getString("response_metric");
				}

				szJArray = DBUtility.getDimension(dimID);
				for (int j = 0; j < szJArray.length(); j++) {
					parDimName = szJArray.getJSONObject(j).getString("parent_dimension_name");
					parDimID = szJArray.getJSONObject(j).getInt("parent_dimension");
					secDimName = szJArray.getJSONObject(j).getString("dimension_name");
				}

				szJArray = DBUtility.getUserResponse(request.getUserID(), request.getToolID(), request.getProjectID(),	request.getQuestionnaireID(), request.getPageID(), questionID, parDimID, dimID, szJObj.getString("response_metric_id"));
				for (int j = 0; j < szJArray.length(); j++) {
					optionID = szJArray.getJSONObject(j).getInt("option_id");
				}
				szLogger.debug("User selected option::" + optionID);

				szMet = new Metric();
				szMet.setMetricID(metricID);
				szMet.setMetricName(szStr);
				
				optLables = szJObj.getString("reponse_options_label").split(",");
				optIDs = szJObj.getString("option_ids").split(",");
				for (int k = 0; k < optLables.length; k++) {
					spliArr = optLables[k].split("-");
					if (spliArr.length > 1) {
						szOpt = new Option(spliArr[0], Integer.parseInt(optIDs[k]), spliArr[1], false);
					} else {
						szOpt = new Option(optLables[k], Integer.parseInt(optIDs[k]), "", false);
					}
					if (Integer.parseInt(optIDs[k]) == optionID) {
						szLogger.debug(optionID + "set to true");
						szOpt.setSelected(true);
					}
					szMet.addOption(szOpt);
				}

				szPQtn = AppUtility.findQuestionForDimension(szTLGPage, parDimID);
				if (szPQtn != null) {
					szLogger.debug("Page Question is not null");
					szDim = AppUtility.getSD(szPQtn, dimID);
					if (szDim == null) {
						szLogger.debug("Secondary dimension is null");
						szDim = new Dimension();
						szDim.setId(dimID);
						szDim.setName(secDimName);
						szQues = new Question();
						szQues.setID(questionID);
						szQues.setNo(szJObj.getInt("question_no"));
						szQues.setContext(szJObj.getString("question_context"));
						szQues.setDescription(szJObj.getString("question_description"));
						szQues.setType(szJObj.getString("question_type"));
						szDim.addQuestion(szQues);
						szPQtn.addSD(szDim);
						no_of_questions++;
					}
					szLogger.debug("Secondary dimension is found");
					szQues = AppUtility.getQuestion(szDim, questionID);
					if (szQues == null) {
						szLogger.debug("Question is null");
						szQues = new Question();
						szQues.setID(questionID);
						szQues.setNo(szJObj.getInt("question_no"));
						szQues.setContext(szJObj.getString("question_context"));
						szQues.setDescription(szJObj.getString("question_description"));
						szQues.setType(szJObj.getString("question_type"));
						szDim.addQuestion(szQues);
						no_of_questions++;
					}
					szLogger.debug("Question is found");
					szQues.addMetric(szMet);
				} else {
					szLogger.debug("Page Question is null");
					szPQtn = new PageQuestion();
					szPQtn.setPdID(parDimID);
					szPQtn.setPdName(parDimName);
					szDim = new Dimension();
					szDim.setId(dimID);
					szDim.setName(secDimName);
					szQues = new Question();
					szQues.setID(questionID);
					szQues.setNo(szJObj.getInt("question_no"));
					szQues.setContext(szJObj.getString("question_context"));
					szQues.setDescription(szJObj.getString("question_description"));
					szQues.setType(szJObj.getString("question_type"));
					szQues.addMetric(szMet);
					szDim.addQuestion(szQues);
					no_of_questions++;
					szPQtn.addSD(szDim);
					szTLGPage.addPageQuestion(szPQtn);
				}
			}
			szPageKey = new Key(request.getUserID(), request.getTeamID(), request.getToolID(), request.getProjectID(),	request.getQuestionnaireID(), request.getPageID(), no_of_questions);
			szTLGPage.setPageKey(szPageKey);
			szLogger.debug("TLG Page::" + (new org.json.JSONObject(szTLGPage)).toString());
			return szTLGPage;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			pageJSON = null;
			szJArray = null;
			szJObj = null;
			optLables = null;
			pw = null;
			sw = null;
		}
	}

	public static GenericResponse savePage(Page page) throws TLGException {
		PageQuestion szPQuest = null;
		String userID = null;
		String projectID = null;
		String toolID = null;
		String questionnaireID = null;
		String pageID = null;
		String questnID = null;
		String teamID = null;
		int priDimID, secDimID;
		String resMetricID = null;
		ArrayList<PageQuestion> pageQuestions = null;
		ArrayList<Dimension> secDimensions = null;
		Dimension szSecDim = null;
		ArrayList<Question> questionList = null;
		Question szQtn = null;
		ArrayList<Metric> metricList = null;
		Metric szMetric = null;
		ArrayList<Option> optionsArr = null;
		Option szOption = null;
		int updateIfExists;
		JSONArray szJSONArr;
		JSONObject szJObj = null;
		float score = -1;
		float max_score = -1;
		float perc_score = -1;
		PrintWriter pw = null;
		StringWriter sw = null;
		boolean questionAnswered = false;
		
		try {
			pageQuestions = page.getPageQuestions();
			toolID = page.getPageKey().getToolID();
			userID = page.getPageKey().getUserID();
			projectID = page.getPageKey().getProjectID();
			pageID = page.getPageKey().getPageID();
			questionnaireID = page.getPageKey().getQuestionnaireID();
			teamID = page.getPageKey().getTeamID();
			for (int i = 0; i < pageQuestions.size(); i++) {
				szPQuest = page.getPageQuestions().get(i);
				priDimID = szPQuest.getPdID();
				secDimensions = szPQuest.getSdlist();
				for (int j = 0; j < secDimensions.size(); j++) {
					szSecDim = secDimensions.get(j);
					secDimID = szSecDim.getId();
					questionList = szSecDim.getQuestions();
					for (int k = 0; k < questionList.size(); k++) {
						szQtn = questionList.get(k);
						questnID = szQtn.getID();
						metricList = szQtn.getMetrics();
						for (int l = 0; l < metricList.size(); l++) {
							szMetric = metricList.get(l);
							resMetricID = szMetric.getMetricID();
							optionsArr = szMetric.getOptions();
							questionAnswered = false;
							for (int p = 0; p < optionsArr.size(); p++) {
								szOption = optionsArr.get(p);
								if (szOption.isSelected()) {
									questionAnswered = true;
									score = -1;
									max_score = -1;
									perc_score = -1;
									szJSONArr = DBUtility.getUserOptionScore(toolID, questionnaireID, szQtn.getID(), resMetricID,
											szOption.getID());
									for (int x = 0; x < szJSONArr.length(); x++) {
										szJObj = szJSONArr.getJSONObject(x);
										score = szJObj.getFloat("score");
									}
									szJSONArr = DBUtility.getQuestionMaxScore(toolID, questionnaireID, pageID, questnID,
											secDimID, resMetricID);
									for (int x = 0; x < szJSONArr.length(); x++) {
										szJObj = szJSONArr.getJSONObject(x);
										max_score = szJObj.getFloat("max_score");
									}
									perc_score = (score / max_score) * 100;
									updateIfExists = -1;
									updateIfExists = DBUtility.updateInsertUserResponse(userID, teamID, toolID,
											projectID, questionnaireID, pageID, questnID, priDimID, secDimID, resMetricID,
											szOption.getType(), szOption.getID(), szOption.getLabel(), score,
											perc_score, max_score);
									szLogger.debug("updateIfExists::" + updateIfExists);
								}
							}
							if(!questionAnswered) {
								szLogger.error("Question " + questnID + " not answered by user " + userID);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szPQuest = null;
			pageQuestions = null;
			secDimensions = null;
			szSecDim = null;
			metricList = null;
			szMetric = null;
			questionList = null;
			szMetric = null;
			szOption = null;
			optionsArr = null;
			szJSONArr = null;
			szJObj = null;
			pw = null;
			sw = null;
		}
		return null;
	}

	public static DashboardList getDashbordList(GenericRequest request) throws TLGException {
		JSONArray DashboardJSON = null;
		DashboardList dbTLGDashboard = null;
		JSONObject dbObj = null;
		Dashboard dbDab = null;
		StringWriter sw = null;
		PrintWriter pw = null;

		try {
			szLogger.debug("ToolID::" + request.getToolID());
			szLogger.debug("ProjectID::" + request.getProjectID());
			DashboardJSON = DBUtility.getDashboardList(request.getProjectID(), request.getToolID());
			szLogger.debug("DashboardJSON::" + DashboardJSON);
			dbTLGDashboard = new DashboardList();

			dbTLGDashboard.setProjectID(request.getProjectID());
			dbTLGDashboard.setToolID(request.getToolID());

			for (int i = 0; i < DashboardJSON.length(); i++) {
				dbObj = DashboardJSON.getJSONObject(i);
				dbDab = new Dashboard();
				dbDab.setID(dbObj.getString("dashboard_id"));
				dbDab.setName(dbObj.getString("dashboard_name"));
				dbDab.setEntityType(dbObj.getString("entity_type"));
				dbDab.setEntityID(dbObj.getString("entity_id"));
				dbDab.setJSONURL(dbObj.getString("dashboard_json"));
				dbTLGDashboard.addDashboard(dbDab);
			}
			szLogger.debug("dbTLGDashboard" + (new org.json.JSONObject(dbTLGDashboard)).toString());
			return dbTLGDashboard;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			DashboardJSON = null;
			dbObj = null;
			sw = null;
			pw = null;
		}
	}

	public static Questionnaire getQuestionnaire(GenericRequest request) throws TLGException {
		Questionnaire szQuestionnaire = null;
		JSONArray szJSONArr = null;
		String toolID = null;
		String questionnaireID = null;
		JSONObject szJSON = null;
		PageSummary pageSum = null;
		String toolVersion = null;
		PrintWriter pw = null;
		StringWriter sw = null;
		
		try {
			toolID = request.getToolID();
			questionnaireID = request.getQuestionnaireID();
			szJSONArr = DBUtility.getQuestionnaire(toolID, questionnaireID);
			szQuestionnaire = new Questionnaire();
			szQuestionnaire.setToolID(request.getToolID());
			szQuestionnaire.setUserID(request.getUserID());
			for (int i = 0; i < szJSONArr.length(); i++) {
				szJSON = szJSONArr.getJSONObject(i);
				szQuestionnaire.setQuestionnaireName(szJSON.getString("questionnaire_name"));
				szQuestionnaire.setQuestionnaireVersion(szJSON.getString("version"));
				szQuestionnaire.setNoOfPages(szJSON.getInt("no_of_pages"));

				pageSum = new PageSummary();
				pageSum.setPageNo(szJSON.getInt("page_no"));
				pageSum.setPageID(szJSON.getString("page_id"));

				szQuestionnaire.addPage(pageSum);
			}
			szJSONArr = DBUtility.getToolVersion(toolID);
			for (int i = 0; i < szJSONArr.length(); i++) {
				szJSON = szJSONArr.getJSONObject(i);
				toolVersion = szJSON.getString("version");
			}
			szQuestionnaire.setToolVersion(toolVersion);
			szQuestionnaire.setQuestionnaireID(request.getQuestionnaireID());
			szQuestionnaire.setUserID(request.getUserID());
			szLogger.debug("Questionnaire::" + (new org.json.JSONObject(szQuestionnaire)).toString());
			return szQuestionnaire;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSONArr = null;
			szJSON = null;
			pw = null;
			sw = null;
		}
	}

	public static PageDetails getPageDetails(GenericRequest request) throws TLGException {
		PageDetails szPageDetails = null;
		JSONArray szJSONArr = null;
		String toolID = null;
		String questionnaireID = null;
		String pageID = null;
		JSONObject szJSON = null;
		String toolVersion = null;
		CommonInfo szComInfo = null;
		StringWriter sw = null;
		PrintWriter pw = null;
		
		try {
			toolID = request.getToolID();
			questionnaireID = request.getQuestionnaireID();
			pageID = request.getPageID();
			szJSONArr = DBUtility.getPageDetails(toolID, questionnaireID, pageID);
			szLogger.debug("PageDetails JSON::" + szJSONArr);
			szPageDetails = new PageDetails();
			szComInfo = new CommonInfo();
			for (int i = 0; i < szJSONArr.length(); i++) {
				szJSON = szJSONArr.getJSONObject(i);
				szPageDetails.setPageID(szJSON.getString("page_id"));
				szPageDetails.setPageNo(szJSON.getInt("page_no"));
				szPageDetails.setQuestionnaireName(szJSON.getString("template_name"));
				szPageDetails.setQuestionnaireVersion(szJSON.getString("version"));
				szPageDetails.setToolID(szJSON.getString("tool_id"));
				szPageDetails.setUserID(request.getUserID());
				szComInfo.setInstructions_to_fill(szJSON.getString("instruction_to_fill"));
				szComInfo.setRemarks(szJSON.getString("remarks"));
				szComInfo.setScoring_guidelines(szJSON.getString("scoring_guidelines"));
				szComInfo.setTitle(szJSON.getString("title"));
				szPageDetails.setCommonInfo(szComInfo);
			}
			szJSONArr = DBUtility.getToolVersion(toolID);
			for (int i = 0; i < szJSONArr.length(); i++) {
				szJSON = szJSONArr.getJSONObject(i);
				toolVersion = szJSON.getString("version");
			}
			szPageDetails.setToolVersion(toolVersion);
			return szPageDetails;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSONArr = null;
			szJSON = null;
			sw = null;
			pw = null;
		}
	}

	public static GenericResponse submitQuestionnaire(GenericRequest request) throws TLGException {
		String toolID = null;
		String questionnaireID = null;
		String projectID = null;
		String teamID = null;
		String userID = null;
		String orgID = null;
		int submitStatus = -1;
		JSONArray szJSONArr = null;
		PrintWriter pw = null;
		StringWriter sw = null;
		try {
			toolID = request.getToolID();
			questionnaireID = request.getQuestionnaireID();
			projectID = request.getProjectID();
			userID = request.getUserID();
			teamID = request.getTeamID();
			submitStatus = DBUtility.submitQuestionnaire(toolID, questionnaireID, projectID, request.getUserID());
			szLogger.debug("submitQuestionnaire status-1::" + submitStatus);

			if (submitStatus != -1) {
				try {
					szLogger.debug("Start ScoreCard generation");
					ScoreCardGenerator.generateScoreCards(projectID, toolID, questionnaireID, teamID, userID);
					szLogger.debug("Finished ScoreCard generation");
					szLogger.debug("Start Dashborad JSON generation");
					DashboardServiceWrapper dbservice = new DashboardServiceWrapper();
					szJSONArr = DBUtility.getOrganizationID(projectID);
					szLogger.debug("Org JSON::" + szJSONArr);
					for (int i = 0; i < szJSONArr.length(); i++) {
						orgID = szJSONArr.getJSONObject(i).getString("organization_id");
					}
					dbservice.generateAllJsonsForTool(orgID, toolID, projectID);
					/*if (toolID.equals(SST_ID)) {
						dbservice.generateAllJsonsForSST(orgID, toolID, projectID);
					} else if (toolID.equals(SSTBrexit_ID)) {
						dbservice.generateAllJsonsForSSTBR(orgID, toolID, projectID);
					} else if (toolID.equals(LIF_ID)) {
						dbservice.generateAllJsonsForLIF(orgID, toolID, projectID);
					} else if (toolID.equals(AM_ID)) {
						dbservice.generateAllJsonsForAM(orgID, toolID, projectID);
					} else if (toolID.equals(SPP_ID)) {
						dbservice.generateAllJsonsForSPP(orgID, toolID, projectID);
					} else if (toolID.equals(CB_ID)) {
						dbservice.generateAllJsonsForCB(orgID, toolID, projectID);
					} else if (toolID.equals(SD_ID)) {
						dbservice.generateAllJsonsForSD(orgID, toolID, projectID);
					} else if (toolID.equals(RG_ID)) {
						dbservice.generateAllJsonsForRANDG(orgID, toolID, projectID);
					} else if (toolID.equals(BEF_ID)) {
						dbservice.generateAllJsonsForBEF(orgID, toolID, projectID);
					}*/

					szLogger.debug("Finished Dashboard JSON generation");
					GenericResponse genRes = new GenericResponse("submitQuestionnaire", 1, null, null);
					return genRes;

				} catch (Exception e) {
					e.printStackTrace();
					sw = new StringWriter();
					pw = new PrintWriter(sw);
					e.printStackTrace(pw);
					TLGException tlgExcep = new TLGException(sw.toString());
					throw tlgExcep;
				}
			}
			GenericResponse genRes = new GenericResponse("submitQuestionnaire", -1, null, null);
			return genRes;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			pw = null;
			sw = null;
			szJSONArr = null;
		}
	}

	public static LoginResponse getUserDetail(LoginRequest request)
			throws MissingRequestParameterException, TLGException {

		LoginResponse dbLoginResponse = null;
		JSONArray szJSONArr = null;
		String username = null;
		String password = null;
		JSONObject szJSON = null;
		StringWriter sw = null;
		PrintWriter pw = null;

		try {
			username = request.getUsername();
			password = request.getPassword();

			if (username == null || username.equalsIgnoreCase("null")) {
				throw new MissingRequestParameterException("username");
			}
			if (password == null || password.equalsIgnoreCase("null")) {
				throw new MissingRequestParameterException("password");
			}

			szLogger.debug("username::" + username);
			szLogger.debug("password::" + password);

			szJSONArr = DBUtility.getUserDetail(username, password);

			szLogger.debug("Login JSON::" + szJSONArr);
			dbLoginResponse = new LoginResponse();
			dbLoginResponse.setUserId(request.getUsername());

			for (int i = 0; i < szJSONArr.length(); i++) {
				szJSON = szJSONArr.getJSONObject(i);
				dbLoginResponse.setID(szJSON.getInt("id"));
				dbLoginResponse.setFirstName(szJSON.getString("first_name"));
				dbLoginResponse.setLastName(szJSON.getString("last_name"));
				dbLoginResponse.setTeamID(szJSON.getString("team_list"));
				dbLoginResponse.setStatus(0);
			}
			if (szJSONArr.length() < 1) {
				TLGException tlgExcep = new TLGException("Username doesn't exist OR Incorrect password");
				throw tlgExcep;
			}
			return dbLoginResponse;
		} catch (MissingRequestParameterException mrpe) {
			szLogger.error("MissingRequestParameterException in getUserDetail");
			throw mrpe;
		} catch (TLGException tlgExcep) {
			throw tlgExcep;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSONArr = null;
			szJSON = null;
			sw = null;
			pw = null;
		}
	}
	
	
	public static Project getProjectList(ProjectRequest request) throws TLGException {
		Project dbProjectResponse = null;
		Project dbProjectResponseAll = null;
		JSONArray szJSONArr = null;
		String userID = null;
		
		JSONObject szJSON = null;
		StringWriter sw = null;
		PrintWriter pw = null;
		
		try {
			userID = request.getUserID();
			szLogger.debug("username::" + userID);
			
			szJSONArr = DBUtility.getProjectList(userID);
			
			szLogger.debug("Project JSON::" + szJSONArr);
			
			dbProjectResponseAll = new Project();

			for (int i = 0; i < szJSONArr.length(); i++) {
				dbProjectResponse = new Project();
				szJSON = szJSONArr.getJSONObject(i);
				dbProjectResponse.setName(szJSON.getString("project_name"));
				
				dbProjectResponse.setProjectID(szJSON.getString("project_id"));
				Object creation_date=szJSON.get("creation_date");
				dbProjectResponse.setDate(creation_date.toString());
				Object start_date_time=szJSON.get("start_date_time");
				dbProjectResponse.setStartTime(start_date_time.toString());
				dbProjectResponse.setStatus(szJSON.getString("status"));
				Object last_modified_date=szJSON.get("last_modified_date");
				dbProjectResponse.setLastModifiedDate(last_modified_date.toString());
				dbProjectResponse.setOrganizationID(szJSON.getString("organization_id"));
				dbProjectResponseAll.addProject(dbProjectResponse);
			}
			
			if (szJSONArr.length() < 1) {
				TLGException tlgExcep = new TLGException("Project List Does not Exist ");
				throw tlgExcep;
			}
			return dbProjectResponseAll;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSONArr = null;
			szJSON = null;
			sw = null;
			pw = null;
		}
	}
	public static Tools getToolList(ToolsRequest request) throws TLGException {
		Tools dbToolsResponse = null;
		Tools dbToolsResponseAll = null;
		JSONArray szJSONArr = null;
		String projectID = null;
		JSONObject szJSON = null;
		StringWriter sw = null;
		PrintWriter pw = null;
		try {
			projectID = request.getProjectID();
			szLogger.debug("username::" + projectID);
			szJSONArr = DBUtility.getToolList(projectID);
			szLogger.debug("Project JSON::" + szJSONArr);
			dbToolsResponseAll = new Tools();
			for (int i = 0; i < szJSONArr.length(); i++) {
				dbToolsResponse = new Tools();
				szJSON = szJSONArr.getJSONObject(i);
				dbToolsResponse.setToolName(szJSON.getString("tool_name"));
				dbToolsResponse.setVersion(szJSON.getString("version"));
				dbToolsResponse.setToolID(szJSON.getString("tool_id"));
				dbToolsResponse.setDescription(szJSON.getString("description"));
				dbToolsResponse.setDescription_url(szJSON.getString("description_url"));
				dbToolsResponse.setBenchmark(szJSON.getInt("benchmark"));
				dbToolsResponse.setOwner(szJSON.getString("owner"));
				if(projectID!=null) {
				dbToolsResponse.setScenario(szJSON.getString("scenario_name"));
				}
				Object creation_date=szJSON.get("creation_date");
				dbToolsResponse.setCreationDate(creation_date.toString());
				Object last_modified_date=szJSON.get("last_modified_date");
				dbToolsResponse.setLastModifiedDate(last_modified_date.toString());
				dbToolsResponseAll.addTools(dbToolsResponse);
			}
			if (szJSONArr.length() < 1) {
				TLGException tlgExcep = new TLGException("tools Detail Does not Exist ");
				throw tlgExcep;
			}
			return dbToolsResponseAll;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSONArr = null;
			szJSON = null;
			sw = null;
			pw = null;
		}
	}
	
	
	public static GenericResponse registerOrg(OrganizationRequest request) throws TLGException {
		int szJSONArr;
		String contact;
		String name;
		String description;
		String companyURL;
		JSONObject szJSON = null;
		StringWriter sw = null;
		PrintWriter pw = null;
		try {
			contact=request.getContact();
			name=request.getName();
			companyURL=request.getCompanyURL();
			description=request.getDescription(); 
			szJSONArr = DBUtility.registerOrg(name,contact,description,companyURL);
			
			szLogger.debug("Project JSON::" + szJSONArr);
			GenericResponse genRes = new GenericResponse("Organization inserted successfully", 1, null, null);
			return genRes;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSON = null;
			sw = null;
			pw = null;
		}
	}
	public static GenericResponse updateOrg(OrganizationRequest request) throws TLGException {
		int szJSONArr;
		String contact;
		String name;
		String description;
		String companyURL;
		String orgID;
		JSONObject szJSON = null;
		StringWriter sw = null;
		PrintWriter pw = null;
		try {
			contact=request.getContact();
			name=request.getName();
			companyURL=request.getCompanyURL();
			description=request.getDescription(); 
			orgID=request.getOrgID();
			szJSONArr = DBUtility.updateOrg(orgID,name,contact,description,companyURL);
			szLogger.debug("Project JSON::" + szJSONArr);
			GenericResponse genRes = new GenericResponse("Organization update successfully", 1, null, null);
			return genRes;
		} catch (Exception e) {
			szLogger.error("Error::" + e.toString());
			e.printStackTrace();
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			TLGException tlgExcep = new TLGException(sw.toString());
			throw tlgExcep;
		} finally {
			szJSON = null;
			sw = null;
			pw = null;
		}
	}
	public static void main(String args[]) throws TLGException {
		
		getProjectList(new ProjectRequest("alex.traill@moorestephens.com"));
		//registerOrg(new OrganizationRequest("test","8812463552","hello","www.meritsystems.com"));
		//updateOrg(new OrganizationRequest("test","test","8815122504","New Project","www.new.com"));
		//getToolList(new ToolsRequest("Navigator"));
		//DashboardList dbTLGDashboard= getDashbordList(new GenericRequest("PR-001","SST-001","rekhas"));
		
	}
}
