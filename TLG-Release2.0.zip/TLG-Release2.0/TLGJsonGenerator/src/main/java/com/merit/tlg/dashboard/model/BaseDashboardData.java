package com.merit.tlg.dashboard.model;

public class BaseDashboardData {

	public String dashBoardId;

	/**
	 * @return the dashBoardId
	 */
	public String getDashBoardId() {
		return dashBoardId;
	}

	/**
	 * @param dashBoardId the dashBoardId to set
	 */
	public void setDashBoardId(String dashBoardId) {
		this.dashBoardId = dashBoardId;
	}
	
	
}
